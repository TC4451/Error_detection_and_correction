import serial
import time

port='COM3'
baud_rate=115200

def send_gcode_line_by_line(gcode_lines):
    print("Starting")
    printer = serial.Serial(port, baud_rate)
    print("Serial object\n", printer)
    time.sleep(20)  # Wait for 10 seconds
    print("end sleep")
    gcode_str = ""
    for line in gcode_lines:
        gcode_command = f'{line}' + ' \r\n'
        print(gcode_command)
        gcode_str += gcode_command
    printer.write(str.encode(gcode_str))


    printer.close()

if __name__ == "__main__":
    # Read G-code lines from the file
    gcode_lines = []
    
    with open("printer_communication/trash/gcode/test2.gcode", "r") as gcode_file:
        for line in gcode_file:
            if line.startswith(";") or line == "\n":
                pass
            elif ';' in line:
                line = line.split(';')[0][:-1]
                gcode_lines.append(line.strip())
            else:
                gcode_lines.append(line.strip())

    # Send G-code to the printer
    send_gcode_line_by_line(gcode_lines)